# Maze-Solving-Agent

In this project, we developed an efficient AI maze solving agent to find the shortest path from source to destination by using Path-Finding algorithms. 

#
#

### Implementation of the following Scheduling Algorithms:
- BFS
- Greedy-Search
- A*

#
#

### User Interface:

![maze](https://github.com/AhmedIssa11/Maze-Solving-Agent/blob/master/maze.png)
